import React from "react";
import NavbarComponent from "./Navbar";
import FooterComponent from "./Footer";
import { Container } from "react-bootstrap";

export default function HomePage() {
    return (
        <>
            <NavbarComponent />
            <Container>
                <h1>Hello Home</h1>
            </Container>
            <FooterComponent />
        </>
    )
}