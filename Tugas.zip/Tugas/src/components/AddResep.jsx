import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Form from 'react-bootstrap/Form';
import NavbarComponent from "./Navbar";
import FooterComponent from "./Footer";
import { Container, Button } from "react-bootstrap";

const AddResep = () => {

    const [name, setName] = useState('')
    const [instruction, setInstruction] = useState('')
    const [description, setDescription] = useState('')
    const navigate = useNavigate()

    const HandleSubmit = (e) => {
        e.preventDefault()
        const menu = { name, instruction, description }

        fetch('http://localhost:3030/resep', {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(menu)
        }).then(() => {
            console.log("New resep added")
        }).then(() => {
            navigate("/")
        })
    }

    const handleCancel = () => {
        navigate("/")
    }

    return (
        // <form onSubmit={HandleSubmit} className="form-container">
        //     <label>Resep Name:</label>
        //     <input 
        //     type="text"
        //     required
        //     value={name}
        //     onChange={(e) => setName(e.target.value)}
        //     />
        //     <label>Resep Ingredients:</label>
        //     <input 
        //     type="number"
        //     required
        //     value={instruction}
        //     onChange={(e) => setInstruction(e.target.value)}
        //     />
        //     <label>Resep Description</label>
        //     <input 
        //     type="text"
        //     required
        //     value={description}
        //     onChange={(e) => setDescription(e.target.value)}
        //     />
        //     <label>Image Link:</label>
        //     <button className="formSubmit">Add Menu</button>
        //     <button type="button" onClick={handleCancel}>Cancel</button>
        // </form>
        <>

            <NavbarComponent />

            <Container>

                <Form>
                    <Form.Group className="mb-3" controlId="formGroupName">
                        <Form.Label>Resep Name</Form.Label>
                        <Form.Control type="text" placeholder="Enter the resep name" value={name} onChange={(e) => setName(e.target.value)} />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="formGroupIngredients">
                        <Form.Label>Resep Ingredients</Form.Label>
                        <Form.Control as="textarea" rows={3} placeholder="Enter the ingredients"  onChange={(e) => setInstruction(e.target.value)}/>
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="formGroupDescription">
                        <Form.Label>Resep Description</Form.Label>
                        <Form.Control as="textarea" rows={3} placeholder="Enter the description" onChange={(e) => setDescription(e.target.value)}/>
                    </Form.Group>

                    <Button variant="primary" type="submit" onClick={HandleSubmit}>
                        Submit
                    </Button>
                    <Button variant="danger" onClick={handleCancel}>
                        Cancel
                    </Button>

                </Form>
            </Container>

            <FooterComponent />
        </>

    )
}

export default AddResep