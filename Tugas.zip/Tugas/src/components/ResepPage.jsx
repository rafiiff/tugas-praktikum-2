import React from "react";
import NavbarComponent from "./Navbar";
import FooterComponent from "./Footer";
import { Fetch } from "./Fetch";

export default function ResepPage() {
    return (
        <>
            <NavbarComponent />
            <Fetch />
            <FooterComponent />
        </>
    )
}