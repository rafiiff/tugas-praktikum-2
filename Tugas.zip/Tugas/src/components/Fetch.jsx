import React, { useEffect, useState } from "react";
import { Card, Button, Container, Col, Row, ListGroup } from "react-bootstrap";


export const Fetch = () => {

    const [resep, setResep] = useState([])

    useEffect(() => {
        fetch("http://localhost:3030/resep")
            .then((res) => res.json())
            .then((json) => setResep(json))
    }, [])

    const handleDelete = (itemId) => {
        fetch(`http://localhost:3030/resep/${itemId}`, {
            method: 'DELETE'
        })
            .then(() => {
                setResep(resep.filter(item => item.id !== itemId))
            })
            .catch(error => {
                console.error('Error deleting item:', error)
            })
    }

    return (
        <div>
            <div>
                <Container fluid>
                    <Row>
                        {resep.map((item) => (
                            <Col key={item.id}>
                                <Card style={{ width: '18rem' }}>
                                    <Card.Img variant="top" src={item.imageUrl} sizes="20px"/>
                                    <Card.Body>
                                        <Card.Title>{item.name}</Card.Title>
                                        <Card.Text>

                                        </Card.Text>
                                        <Button variant="danger" onClick={() => handleDelete(item.id)}>Delete</Button>
                                    </Card.Body>
                                </Card>
                            </Col>
                        ))}

                    </Row>
                </Container>
            </div>
        </div>
    )
}
